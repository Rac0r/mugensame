export default {
  title: "Undertow",
  tagline: "Field notes from the deep",
  description: "Homelab builds, code, and things that live in the dark — an ocean-themed dev blog.",
  year: new Date().getFullYear(),
};
