---
title: SSH Everywhere, Passwords Nowhere
description: Getting a consistent, key-based SSH setup across Linux, Mac, and Windows boxes.
date: 2026-02-18
tags:
  - posts
  - homelab
  - networking
---
The moment a homelab spans more than one machine, password-based SSH stops being a minor annoyance and starts being a daily tax. Paying it down once, properly, is worth the afternoon.

The setup that's held up across a mixed fleet of Linux, macOS, and Windows hosts:

1. **One key per device**, not one key for everything. If a laptop walks out the door, revoking its access shouldn't mean rotating every key you own.
2. **A real `~/.ssh/config`**, with host aliases for everything — so connecting to a box is a name, not an IP and a flag you forgot.
3. **Agent forwarding only where it's actually needed**, which in practice is less often than it feels like it should be.

None of this is exotic, but it's the kind of plumbing that disappears the moment it's done correctly — which is exactly the point.
