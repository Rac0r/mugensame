---
title: Setting Up a Homelab on Unraid
description: Storage pools, containers, and the slow creep toward "just one more service."
date: 2026-05-12
tags:
  - posts
  - homelab
  - self-hosting
---
Every homelab starts the same way: one box, one purpose. Mine started as a NAS and quietly grew into something closer to a small ocean — services drifting in the dark, mostly forgotten until something breaks.

Unraid turned out to be a good fit for this. The array gives me parity protection without forcing every drive into a single filesystem, and the Docker integration means new services are a five-minute decision rather than a weekend project. That's a dangerous kind of convenience.

A few things that made the setup noticeably better:

- **Cache pools** for anything that writes often — keeps the spinning array quiet and asleep most of the day.
- **A dedicated VLAN** for the noisier containers, so a misbehaving service can't see the rest of the network.
- **Scheduled parity checks**, set to run somewhere I won't notice the performance hit.

None of this is exotic. It's mostly just deciding, once, where things should live — and then leaving them alone.
